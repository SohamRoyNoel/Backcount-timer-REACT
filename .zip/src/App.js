import './App.css';
import OuterContainer from './component/OuterContainer';
function App() {
  return (
    <div className="App" style={{ paddingLeft: 20, paddingTop: 10 }}>
      <OuterContainer />
    </div>
  );
}

export default App;
